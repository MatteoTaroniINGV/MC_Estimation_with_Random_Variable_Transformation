% Script to simulate and test exponential magnitudes


%%% INPUT %%%%%%%%%%

% number of simulations for the tests
Simulations = 10^4 ;

% number of events in each sub-catalog
Num1 = 5000 ;
Num2 = 5000 ;

% parameter of the exponential distribution (b-values of the
% Gutenberg-Richter law)
B1 = 0.9 ; 
B2 = 1.1 ; 

%%%%%%%%%%%%%%%%%%%%%



%%% Simulations %%%%%%%%%%%%%%%%%%%

% set off the warnings (for the lillietest MATLAB function)
warning( 'off' )

% loop 'for' to perform different simulations
for i = 1 : Simulations

% simulation of exponential random numbers
Sim1 = exprnd( 1/(B1*log(10)) , Num1 , 1 ) ;
Sim2 = exprnd( 1/(B2*log(10)) , Num2 , 1 ) ;
Sim  = [ Sim1 ; Sim2 ] ;

% transformation from exponential to uniform random variables
Transf = Sim( 1 : 2 : end-1 )./ ( Sim( 1 : 2 : end-1 ) + Sim( 2 : 2 : end ) ) ;

% CDF of the uniform distribution
CDF_Unif = makedist('uniform');

% KS test for uniform distribution
[ H , PvalUnif( i ) ] = kstest( Transf , 'CDF' , CDF_Unif ) ;


% Lilliefors test for exponential distribution
[ HL , PvalExp( i ) ] = lillietest( Sim , 'Distr' , 'exponential' ) ;

% show the remaining number of iterations
Simulations - i

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%% Results %%%%

% percentage of p-values of the KS test below 0.1
Perc_KS     = sum( PvalUnif <= 0.1 ) / Simulations * 100

% percentage of p-values of the Lilliefors test below 0.1
Perc_Lillie = sum( PvalExp  <= 0.1 ) / Simulations * 100

%%%%%%%%%%%%%%%%%%

