function [ MC ] = MC_Computation_With_Transformation( Catalog , Magn_Col , Magn_Bin , Vector_Compl , Pval )

% This function computes the magntiude of completeness of a seismic catalog
% usign the magnitude transformation illustrated in Taroni 2023 - TSR
%
% INPUT
%
% Catalog = the seismic catalog
%
% Magn_Col = the column of the seismic catalog containing the magnitudes
%
% Magn_Bin = binning of the magnitudes (usually is 0.01 or 0.1)
%
% Vector_Compl = the vector with the values of completeness which will be
%                analyzed by the function
%
% Pval = p-value threshold for the complete part of the catalog (usually
%        is 0.1)
%
%
% OUTPUT
%
% MC = the magnitude of completeness of the catalog
%
% Figure = a figure containing the Magnitude Threshold vs P-value plot


% Preallocation to speed-up the computation 
Pvalue_Unif = zeros( 100 , length( Vector_Compl ));

% CDF of the uniform distribution
CDF_Unif = makedist('uniform');

% open waitbar
f = waitbar(0,'Please wait...');
pause(2)

% loop for the different completeness
for i = 1 : length( Vector_Compl )
    
    % loop for the different magnitude errors (here 100 runs)
    for j = 1 : 100
        
        % add the uniform error to the magnitudes
        Magn = Catalog( : , Magn_Col ) + ( rand( size( Catalog , 1 ) , 1 ) - 0.5 ) * Magn_Bin ;
        
        % magntiude selection 
        Magn_Ok = Magn( Magn >= Vector_Compl( i ) ) - Vector_Compl( i ) ;

        % transformation from exponential to uniform random variables
        Transf = Magn_Ok( 1 : 2 : end-1 )./ ( Magn_Ok( 1 : 2 : end-1 ) + Magn_Ok( 2 : 2 : end ) ) ;

        % Kolmogorov-Smirnov test for uniform distribution
        [ H , Pvalue_Unif( j , i ) ] = kstest( Transf , 'CDF' , CDF_Unif ) ;

        % computation for waitbar
        waitbar(((j + 100 * (i - 1))/(100 * length( Vector_Compl ))),f,'Processing your data');
    end  
end

% close waitbar
waitbar(1,f,'Finishing');
pause(2)
delete(f)

% compute the median p-value, and the 5-th and 95-th percentile
P_Mean = mean( Pvalue_Unif ) ;
P_05   = prctile( Pvalue_Unif ,  5 ) ;
P_95   = prctile( Pvalue_Unif , 95 ) ;

% find the magnitude of completeness (first mean p-value >= Pval)
MC = min( Vector_Compl( P_Mean >= Pval ) ) ;

% figure
plot( Vector_Compl , P_Mean , 'k' )
hold on
plot( Vector_Compl , P_05 , '--k' )
plot( Vector_Compl , P_95 , '--k' )
plot( [ MC , MC ] , [ 0 , max(P_95) ] , 'b' )
plot( [ min(Vector_Compl) , max(Vector_Compl) ] , [ Pval , Pval ] , 'r' )
xlim( [ min(Vector_Compl) , max(Vector_Compl) ] )
ylim( [ 0 , max(P_95) ] ) 
xlabel( 'Magnitude Threshold')
ylabel( 'P-value' )







