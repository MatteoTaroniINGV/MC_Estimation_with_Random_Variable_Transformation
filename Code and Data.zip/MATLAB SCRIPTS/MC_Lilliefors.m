function  [ MC ] = MC_Lilliefors( Catalog , Magn_Col , Magn_Bin , Vector_Compl , Pval )

% This function computes the magntiude of completeness of a seismic catalog
% usign the Lilliefors test illustrated in Herrmann and Marzocchi 2021 - SRL
%
% INPUT
%
% Catalog = the seismic catalog
%
% Magn_Col = the column of the seismic catalog containing the magnitudes
%
% Magn_Bin = binning of the magnitudes (usually is 0.01 or 0.1)
%
% Vector_Compl = the vector with the values of completeness which will be
%                analyzed by the function
%
% Pval = p-value threshold for the complete part of the catalog (usually
%        is 0.1)
%
%
% OUTPUT
%
% MC = the magnitude of completeness of the catalog
%
% Figure = a figure containing the Magnitude Threshold vs P-value plot
%
%
%
%  !! The MATLAB function 'lillietest' has a maximum p-value equal to 0.5,
%  !! therefore the figure may show a sort of flat upper part in the case  
%  !! of high p-values of the test


% warning 'off'
% (avoid warning messages in the "lillietest" function
warning('off')

% Preallocation to speed-up the computation 
Pvalue_Lill = zeros( 100 , length( Vector_Compl ));

% open waitbar
f = waitbar(0,'Please wait...');
pause(2)

% loop for the different completeness
for i = 1 : length( Vector_Compl )
    
    % loop for the different magnitude errors (here 100 runs)
    for j = 1 : 100
        
        % add the uniform error to the magnitudes
        Magn = Catalog( : , Magn_Col ) + ( rand( size( Catalog , 1 ) , 1 ) - 0.5 ) * Magn_Bin ;
        
        % magntiude selection 
        Magn_Ok = Magn( Magn >= Vector_Compl( i ) ) - Vector_Compl( i ) ;
        
        % Lilliefors test
        [ H , Pvalue_Lill( j , i ) ] = lillietest( Magn_Ok  , 0.05 ,  'exp' , 'MCTol' , 0.001 ) ;

        % computation for waitbar
        waitbar(((j + 100 * (i - 1))/(100 * length( Vector_Compl ))),f,'Processing your data');
    end  
end

% close waitbar
waitbar(1,f,'Finishing');
pause(2)
delete(f)

% compute the median p-value, and the 5-th and 95-th percentile
P_Mean = mean( Pvalue_Lill ) ;
P_05   = prctile( Pvalue_Lill ,  5 ) ;
P_95   = prctile( Pvalue_Lill , 95 ) ;

% find the magnitude of completeness (first mean p-value >= Pval)
MC = min( Vector_Compl( P_Mean >= Pval ) ) ;

% warning 'on'
warning('on')

% figure
plot( Vector_Compl , P_Mean , 'k' )
hold on
plot( Vector_Compl , P_05 , '--k' )
plot( Vector_Compl , P_95 , '--k' )
plot( [ MC , MC ] , [ 0 , max(P_95) ] , 'b' )
plot( [ min(Vector_Compl) , max(Vector_Compl) ] , [ Pval , Pval ] , 'r' )
xlim( [ min(Vector_Compl) , max(Vector_Compl) ] )
ylim( [ 0 , max(P_95) ] ) 
xlabel( 'Magnitude Threshold')
ylabel( 'P-value' )
