% This script is an example of how to apply the methods based on the
% Lilliefors test and the random variable transformation

% load a simulated incomplete catalog
Catalog = importdata( 'Catalog_Example.txt' ) ;

% vector of magnitude thresholds
Vector_Compl = 0 : 0.1 : 1 ;

% magnitude of completeness estimation based on Lilliefors test
figure
MC_Lill = MC_Lilliefors( Catalog , 1 , 0.01 , Vector_Compl , 0.1 ) ;

% magnitude of completeness estimation based on random variable transformation
figure
MC_Trans = MC_Computation_With_Transformation( Catalog , 1 , 0.01 , Vector_Compl , 0.1 ) ;