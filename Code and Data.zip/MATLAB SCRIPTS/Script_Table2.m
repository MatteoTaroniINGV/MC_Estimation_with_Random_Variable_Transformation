% Script to check the efficacy of the method with incomplete catalogs


%%% INPUT %%%%%%%%%%

% number of simulations for the tests
Simulations = 2*10^3 ;

% number of events in the catalog
Num1 = 3*10^4 ;

% parameter of the exponential distribution (b-value of the
% Gutenberg-Richter law)
B1 = 1.0 ; 

% parameters of the incompleteness filter (Ogata and Katsura 1993)
Mi    = 0.1 ;
Sigma = 0.2 ;

% pre-defined magnitude of completeness
 Magn_Compl = Mi ; 
%Magn_Compl = Mi +   Sigma ;
%Magn_Compl = Mi + 2*Sigma ;

%%%%%%%%%%%%%%%%%%%%%

% set off the warnings (for the lillietest MATLAB function)
warning( 'off' )

% CDF of the uniform distribution
CDF_Unif = makedist('uniform');

% preallocation of number of events and p-value vectors
NumEvents = zeros( 1 , Simulations ) ;
PvalUnif  = zeros( 1 , Simulations ) ;
PvalExp   = zeros( 1 , Simulations ) ;

% loop 'for' to compute the p-values of the tests
for i =  1 : Simulations 

    % simulation of exponential random numbers
    Sim1 = exprnd( 1/(B1*log(10)) , Num1 , 1 ) ;

    % incompleteness filter (Ogata and Katsura 1993)
    Rand1   = rand( Num1 , 1 ) ;                      % uniform random simulation
    Ind1    = Rand1 < normcdf( Sim1 , Mi , Sigma ) ;  % index of the remaining events
    Sim_Inc = Sim1( Ind1 ) ;                          % incomplete catalog

    % selection of the events above the completeness and their adjustment
    Sim_Inc_Ok = Sim_Inc( Sim_Inc >= Magn_Compl ) - Magn_Compl ; 

    % number of events in this catalog
    NumEvents( i ) = length( Sim_Inc_Ok ) ;

    % transformation from exponential to uniform random variables
    Transf = Sim_Inc_Ok( 1 : 2 : end-1 )./ ( Sim_Inc_Ok( 1 : 2 : end-1 ) + Sim_Inc_Ok( 2 : 2 : end ) ) ;

    % KS test for uniform distribution
    [ H , PvalUnif(i) ] = kstest( Transf , 'CDF' , CDF_Unif ) ;

    % Lilliefors test for exponential distribution
    [ HL , PvalExp(i) ] = lillietest( Sim_Inc_Ok , 'Distr' , 'exponential' ) ;

    % show the remaining number of iterations
    Simulations - i

end


% results: mean number of events and percentages of p-value smaller or equal than 0.1
Mean_Number_Events = mean( NumEvents )
Perc_PvalUnif = sum( PvalUnif <= 0.1 )/Simulations * 100
Perc_PvalExp  = sum( PvalExp  <= 0.1 )/Simulations * 100
