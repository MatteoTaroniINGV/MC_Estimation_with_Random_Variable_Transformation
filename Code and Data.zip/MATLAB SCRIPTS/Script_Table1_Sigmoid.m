% Script to simulate and test exponential magnitudes
% Version 2: events blended by a sigmoid function


%%% INPUT %%%%%%%%%%

% number of simulations for the tests
Simulations = 10^4 ;

% number of events in each sub-catalog
Num1 = 15000 ;
Num2 = 20000 ;

% parameter of the exponential distribution (b-values of the
% Gutenberg-Richter law)
B1 = 0.9 ; 
B2 = 1.1 ; 

%%%%%%%%%%%%%%%%%%%%%



%%% Simulations %%%%%%%%%%%%%%%%%%%

% set off the warnings (for the lillietest MATLAB function)
warning( 'off' )

% preallocation of p-value vectors
PvalUnif  = zeros( 1 , Simulations ) ;
PvalExp   = zeros( 1 , Simulations ) ;


% loop 'for' to perform different simulations
for i = 1 : Simulations

% simulation of exponential random numbers
Sim1 = exprnd( 1/(B1*log(10)) , Num1+Num2 , 1 ) ;
Sim2 = exprnd( 1/(B2*log(10)) , Num1+Num2 , 1 ) ;

% merging of the two sub-catalogs using a sigmoid function
alpha = 200 ;                                                 % parameter of the sigmoid function
X = 1 : 1 : Num1+Num2 ;
SigmoidFunction = ( 1 + exp( - ( X - Num1 )/alpha ) ).^(-1) ; % sigmoid function centered in X = Num1
RandomNumbers   = rand( 1 , Num1+Num2 ) ;                     % random numbers between 0 and 1
Ind1 = SigmoidFunction <= RandomNumbers ;                     % index of events from the first sub-catalog
Ind2 = SigmoidFunction  > RandomNumbers ;                     % index of events from the second sub-catalog
Sim  = [ Sim1( Ind1 ) ; Sim2( Ind2 ) ] ;

% transformation from exponential to uniform random variables
Transf = Sim( 1 : 2 : end-1 )./ ( Sim( 1 : 2 : end-1 ) + Sim( 2 : 2 : end ) ) ;

% CDF of the uniform distribution
CDF_Unif = makedist('uniform');

% KS test for uniform distribution
[ H , PvalUnif( i ) ] = kstest( Transf , 'CDF' , CDF_Unif ) ;


% Lilliefors test for exponential distribution
[ HL , PvalExp( i ) ] = lillietest( Sim , 'Distr' , 'exponential' ) ;

% show the remaining number of iterations
Simulations - i

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%%% Results %%%%

% percentage of p-values of the KS test below 0.1
Perc_KS     = sum( PvalUnif <= 0.1 ) / Simulations * 100

% percentage of p-values of the Lilliefors test below 0.1
Perc_Lillie = sum( PvalExp  <= 0.1 ) / Simulations * 100

%%%%%%%%%%%%%%%%%%
